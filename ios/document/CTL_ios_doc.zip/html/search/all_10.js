var searchData=
[
  ['willaddentries',['willAddEntries',['../category_l_o_location_observer_07_friend_08.html#ac514282f087e5a6c6851b494a0baede4',1,'LOLocationObserver(Friend)::willAddEntries()'],['../interface_l_o_location_observer.html#ac514282f087e5a6c6851b494a0baede4',1,'LOLocationObserver::willAddEntries()']]],
  ['willremoveentries',['willRemoveEntries',['../category_l_o_location_observer_07_friend_08.html#af4debcb3fb4b538a9ec3d620653850c2',1,'LOLocationObserver(Friend)::willRemoveEntries()'],['../interface_l_o_location_observer.html#af4debcb3fb4b538a9ec3d620653850c2',1,'LOLocationObserver::willRemoveEntries()']]]
];
