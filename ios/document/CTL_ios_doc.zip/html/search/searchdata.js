var indexSectionsWithContent =
{
  0: "acdefgilmnopqstuw",
  1: "cln",
  2: "dfilopqsuw",
  3: "aegmot"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Properties"
};

