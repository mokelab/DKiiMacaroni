var searchData=
[
  ['initwithobserver_3aselector_3a',['initWithObserver:selector:',['../interface_l_o_location_observer.html#a9d35e0a2a9f72d4b944db03f811e2ffd',1,'LOLocationObserver']]]
];
