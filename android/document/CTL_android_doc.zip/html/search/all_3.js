var searchData=
[
  ['fetch',['fetch',['../classjp_1_1upft_1_1content__trigger_1_1_content_trigger_client.html#a53b4822f5efb252e98eacd2af103e736',1,'jp::upft::content_trigger::ContentTriggerClient']]]
];
