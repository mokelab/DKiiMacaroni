var searchData=
[
  ['locationobserver',['LocationObserver',['../classjp_1_1upft_1_1location__observer_1_1_location_observer.html',1,'jp::upft::location_observer']]]
];
