var searchData=
[
  ['qrobserver',['QRObserver',['../classjp_1_1upft_1_1content__trigger_1_1core_1_1observer_1_1_q_r_observer.html',1,'jp::upft::content_trigger::core::observer']]]
];
