var searchData=
[
  ['persistencemanager',['PersistenceManager',['../classjp_1_1upft_1_1location__observer_1_1_location_observer_1_1_persistence_manager.html',1,'jp::upft::location_observer::LocationObserver']]]
];
