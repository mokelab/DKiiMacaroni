var searchData=
[
  ['geofenceobserveentrybuilder',['GeofenceObserveEntryBuilder',['../classjp_1_1upft_1_1location__observer_1_1geofence__observer_1_1_geofence_observe_entry_builder.html',1,'jp::upft::location_observer::geofence_observer']]],
  ['geofenceobserver',['GeofenceObserver',['../classjp_1_1upft_1_1location__observer_1_1geofence__observer_1_1_geofence_observer.html',1,'jp::upft::location_observer::geofence_observer']]]
];
